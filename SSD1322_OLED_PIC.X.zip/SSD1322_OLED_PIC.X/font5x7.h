#ifndef FONT5X7_H
#define FONT5X7_H

#include <stdint.h>

/* ASCII tartom�ny */
#define FONT5X7_FIRST_CHAR 32
#define FONT5X7_CHAR_COUNT 96

extern const uint8_t font5x7[][5];

#endif