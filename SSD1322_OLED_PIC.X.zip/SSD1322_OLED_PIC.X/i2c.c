#include <xc.h>
#include <stdint.h>
#include "i2c.h"

void I2C_Init(void)
{
    // Hardware MSSP pins: RB4 = SDA, RB6 = SCL.
    TRISBbits.TRISB4 = 1;
    TRISBbits.TRISB6 = 1;

    // I2C Master mode, clock = Fosc / (4 * (SSPADD + 1)).
    SSPCON1 = 0x28;
    SSPSTAT = 0x00;

    /*
     * At 20 MHz, SSPADD = 12 gives about 384.6 kHz.
     * This is Fast-mode and stays below the OLED's 400 kHz limit.
     */
    SSPADD = 12;
}

void I2C_Wait(void)
{
    while ((SSPCON2 & 0x1F) || SSPSTATbits.R_nW)
    {
    }
}

void I2C_Start(void)
{
    I2C_Wait();
    SSPCON2bits.SEN = 1;

    while (SSPCON2bits.SEN)
    {
    }
}

void I2C_Stop(void)
{
    I2C_Wait();
    SSPCON2bits.PEN = 1;

    while (SSPCON2bits.PEN)
    {
    }
}

void I2C_Write(uint8_t data)
{
    I2C_Wait();
    SSPBUF = data;

    while (SSPSTATbits.BF)
    {
    }

    I2C_Wait();
}
