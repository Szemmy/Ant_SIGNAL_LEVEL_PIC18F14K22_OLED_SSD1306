#include <xc.h>
#include <stdint.h>
#include "buzzer.h"

#define BUZZER_PULSE_MS 30U
#define BUZZER_PWM_PR2 124U
#define BUZZER_PWM_DUTY 62U

static uint16_t timeToEventMs;
static uint8_t pulseActive;

static void BuzzerToneOn(void)
{
    /*
     * PWM frequency = Fosc / (4 * (PR2 + 1) * prescaler)
     * 20 MHz / (4 * 125 * 16) = 2.5 kHz.
     * P1B is the ECCP1 PWM output on RC4.
     */
    PSTRCON = 0x02;
    CCPR1L = BUZZER_PWM_DUTY;
    CCP1CON = 0x2C;
    T2CON = 0x06;
}

static void BuzzerToneOff(void)
{
    CCP1CON = 0x00;
    T2CON = 0x00;
    PSTRCON = 0x00;
    LATCbits.LATC4 = 0;
}

static uint16_t BuzzerIntervalMs(int8_t signalDb)
{
    /* The measured idle floor is around -71 dB, so it stays silent. */
    if (signalDb <= -65)
    {
        return 0;
    }
    else if (signalDb <= -60)
    {
        return 1000;
    }
    else if (signalDb <= -55)
    {
        return 700;
    }
    else if (signalDb <= -50)
    {
        return 450;
    }
    else if (signalDb <= -45)
    {
        return 280;
    }

    return 150;
}

void Buzzer_Init(void)
{
    TRISCbits.TRISC4 = 0;
    PR2 = BUZZER_PWM_PR2;
    Buzzer_Silence();
}

void Buzzer_Silence(void)
{
    BuzzerToneOff();
    timeToEventMs = 0;
    pulseActive = 0;
}

void Buzzer_Update(int8_t signalDb, uint8_t enabled, uint16_t elapsedMs)
{
    uint16_t intervalMs;

    intervalMs = BuzzerIntervalMs(signalDb);

    if ((!enabled) || (intervalMs == 0))
    {
        Buzzer_Silence();
        return;
    }

    if (timeToEventMs > elapsedMs)
    {
        timeToEventMs -= elapsedMs;
        return;
    }

    if (pulseActive)
    {
        BuzzerToneOff();
        pulseActive = 0;
        timeToEventMs = intervalMs - BUZZER_PULSE_MS;
    }
    else
    {
        BuzzerToneOn();
        pulseActive = 1;
        timeToEventMs = BUZZER_PULSE_MS;
    }
}
