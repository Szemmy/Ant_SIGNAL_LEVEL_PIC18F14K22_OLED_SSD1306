#ifndef SETTINGS_H
#define SETTINGS_H

#include <stdint.h>

typedef struct
{
    uint8_t contrast;
    uint8_t beepEnabled;
    int8_t barMaxDb;
} Settings;

void Settings_Load(Settings *settings);
void Settings_Save(const Settings *settings);

#endif /* SETTINGS_H */
