#ifndef SH1106_H
#define	SH1106_H

#include <xc.h>        
#include <stdint.h>    

// EZ HI�NYZOTT A .H F�JLODB�L, AZ�RT NEM L�TTA A .C F�JL!
#define SH1106_ADDR 0x3C
#define SH1106_CMD  0x00
#define SH1106_DATA 0x40

// F�ggv�nyek protot�pusai (A SH1106_Data is hozz�adva)
void SH1106_Init(void);
void SH1106_Command(uint8_t command);
void SH1106_Data(uint8_t data);
void SH1106_SetPosition(uint8_t x, uint8_t page);
void SH1106_Char(uint8_t x, uint8_t page, char c);
void SH1106_String(uint8_t x, uint8_t page, const char *text);
void SH1106_WritePage(uint8_t page, uint8_t pattern);
void SH1106_Clear(void);
void SH1106_Fill(uint8_t pattern);
void SH1106_TestPattern(void);

#endif	/* SH1106_H */