#include <xc.h>
#include <stdint.h>
#include "adc.h"

#define _XTAL_FREQ 20000000UL

void ADC_Init(void)
{
    /* RC0 = AN4: battery divider; RC2 = AN6: AD8307 output. */
    TRISCbits.TRISC0 = 1;
    TRISCbits.TRISC2 = 1;
    ANSELbits.ANS4 = 1;
    ANSELbits.ANS6 = 1;

    /* Neither analog pin is used as a comparator input. */
    CM1CON0 = 0x00;
    CM2CON0 = 0x00;

    /* Vref+ = VDD, Vref- = VSS; result is right-justified. */
    ADCON1 = 0x00;

    /* Fosc/64 = 3.2 us TAD; automatic acquisition = 12 TAD. */
    ADCON2 = 0xAE;
    ADCON0 = 0x01;
}

uint16_t ADC_Read(uint8_t channel)
{
    ADCON0bits.CHS = channel;
    ADCON0bits.ADON = 1;
    ADCON0bits.GO_nDONE = 1;

    while (ADCON0bits.GO_nDONE)
    {
    }

    return (((uint16_t)ADRESH << 8) | ADRESL);
}

uint16_t ADC_ReadAverage(uint8_t channel, uint8_t samples)
{
    uint8_t index;
    uint32_t total;

    if (samples == 0)
    {
        return 0;
    }

    total = 0;

    for (index = 0; index < samples; index++)
    {
        total += ADC_Read(channel);
    }

    return (uint16_t)((total + (samples / 2U)) / samples);
}
