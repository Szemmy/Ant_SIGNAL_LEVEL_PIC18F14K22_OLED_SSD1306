#include <xc.h>
#include <stdint.h>
#include "settings.h"

#define SETTINGS_MAGIC_VALUE 0xA7U
#define EEPROM_ADDR_MAGIC    0U
#define EEPROM_ADDR_CONTRAST 1U
#define EEPROM_ADDR_BEEP     2U
#define EEPROM_ADDR_BAR_MAX  3U

#define DEFAULT_CONTRAST     96U
#define DEFAULT_BEEP_ENABLED 1U
#define DEFAULT_BAR_MAX_DB   (-15)

static uint8_t EEPROM_ReadByte(uint8_t address)
{
    EEADR = address;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.RD = 1;

    return EEDATA;
}

static void EEPROM_WriteByte(uint8_t address, uint8_t value)
{
    if (EEPROM_ReadByte(address) == value)
    {
        return;
    }

    EEADR = address;
    EEDATA = value;
    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS = 0;
    EECON1bits.WREN = 1;

    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;

    while (EECON1bits.WR)
    {
    }

    EECON1bits.WREN = 0;
}

static void Settings_SetDefaults(Settings *settings)
{
    settings->contrast = DEFAULT_CONTRAST;
    settings->beepEnabled = DEFAULT_BEEP_ENABLED;
    settings->barMaxDb = DEFAULT_BAR_MAX_DB;
}

void Settings_Load(Settings *settings)
{
    uint8_t contrast;
    uint8_t beepEnabled;
    int8_t barMaxDb;

    if (EEPROM_ReadByte(EEPROM_ADDR_MAGIC) != SETTINGS_MAGIC_VALUE)
    {
        Settings_SetDefaults(settings);
        return;
    }

    contrast = EEPROM_ReadByte(EEPROM_ADDR_CONTRAST);
    beepEnabled = EEPROM_ReadByte(EEPROM_ADDR_BEEP);
    barMaxDb = (int8_t)EEPROM_ReadByte(EEPROM_ADDR_BAR_MAX);

    if ((contrast < 32U) || (contrast > 160U) ||
        (beepEnabled > 1U) || (barMaxDb < -30) || (barMaxDb > 0))
    {
        Settings_SetDefaults(settings);
        return;
    }

    settings->contrast = contrast;
    settings->beepEnabled = beepEnabled;
    settings->barMaxDb = barMaxDb;
}

void Settings_Save(const Settings *settings)
{
    EEPROM_WriteByte(EEPROM_ADDR_CONTRAST, settings->contrast);
    EEPROM_WriteByte(EEPROM_ADDR_BEEP, settings->beepEnabled);
    EEPROM_WriteByte(EEPROM_ADDR_BAR_MAX, (uint8_t)settings->barMaxDb);
    EEPROM_WriteByte(EEPROM_ADDR_MAGIC, SETTINGS_MAGIC_VALUE);
}
