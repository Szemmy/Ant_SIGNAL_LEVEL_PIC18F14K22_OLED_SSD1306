#include <xc.h>
#include <stdint.h>
#include "SSD1306.h"
#include "adc.h"
#include "buzzer.h"
#include "i2c.h"
#include "logo.h"
#include "menu.h"
#include "power.h"
#include "settings.h"

#define _XTAL_FREQ 20000000UL

// ======================================================
// CONFIGURATION BITS - 20 MHz external crystal
// ======================================================

#pragma config FOSC = HS
#pragma config PLLEN = OFF
#pragma config PCLKEN = ON
#pragma config FCMEN = OFF
#pragma config IESO = OFF

#pragma config PWRTEN = ON
#pragma config BOREN = ON
#pragma config BORV = 19

#pragma config WDTEN = OFF
#pragma config WDTPS = 32768

#pragma config MCLRE = ON
#pragma config HFOFST = OFF

#pragma config STVREN = ON
#pragma config LVP = OFF
#pragma config XINST = OFF

/* ADC reference, resistor divider and initial AD8307 transfer curve. */
#define ADC_VDD_MV               5000UL
#define BATTERY_TOP_RESISTOR_KOHM 100UL
#define BATTERY_BOTTOM_RESISTOR_KOHM 68UL
#define BATTERY_DIODE_DROP_CENTIVOLTS 27U
#define BATTERY_ADC_CHANNEL       4U
#define SIGNAL_ADC_CHANNEL        6U
#define ADC_AVERAGE_SAMPLES       8U
#define MAIN_LOOP_TICK_MS          10U
#define DISPLAY_UPDATE_TICKS       25U
#define STARTUP_LOGO_DELAY_STEPS    15U

/*
 * The measured idle floor is about -71 dB. This range leaves it near the
 * bottom of the bar and keeps hand/antenna changes away from saturation.
 */
#define SIGNAL_BAR_MIN_DB        (-75)

static uint16_t BatteryCentiVolts(uint16_t adcCount)
{
    uint32_t numerator;
    uint32_t denominator;

    numerator = (uint32_t)adcCount * ADC_VDD_MV;
    numerator *= (BATTERY_TOP_RESISTOR_KOHM + BATTERY_BOTTOM_RESISTOR_KOHM);
    denominator = 1023UL * BATTERY_BOTTOM_RESISTOR_KOHM * 10UL;

    return (uint16_t)(((numerator + (denominator / 2UL)) / denominator) +
                      BATTERY_DIODE_DROP_CENTIVOLTS);
}

static int8_t AD8307dB(uint16_t adcCount)
{
    uint16_t outputMilliVolts;
    int16_t signalDb;

    outputMilliVolts = (uint16_t)(((uint32_t)adcCount * ADC_VDD_MV + 511UL) / 1023UL);

    /* AD8307 factory transfer curve: Vout = 25 mV/dB * (Pin + 84 dBm). */
    signalDb = (int16_t)((outputMilliVolts + 12U) / 25U) - 84;

    if (signalDb < -99)
    {
        signalDb = -99;
    }
    else if (signalDb > 0)
    {
        signalDb = 0;
    }

    return (int8_t)signalDb;
}

static uint8_t SignalBarSegments(int8_t signalDb, int8_t barMaxDb)
{
    int16_t scaled;

    if (signalDb <= SIGNAL_BAR_MIN_DB)
    {
        return 0;
    }

    if (signalDb >= barMaxDb)
    {
        return 12;
    }

    scaled = ((int16_t)(signalDb - SIGNAL_BAR_MIN_DB) * 12) +
             ((barMaxDb - SIGNAL_BAR_MIN_DB) / 2);

    return (uint8_t)(scaled / (barMaxDb - SIGNAL_BAR_MIN_DB));
}

static void ShowStartupLogo(void)
{
    uint8_t delayStep;

    Logo_Draw();

    for (delayStep = 0; delayStep < STARTUP_LOGO_DELAY_STEPS; delayStep++)
    {
        __delay_ms(100);
    }
}

void main(void)
{
    uint16_t batteryAdc;
    uint16_t signalAdc;
    uint16_t batteryCentivolts;
    int8_t signalDb;
    int8_t peakDb;
    uint8_t screenInitialized;
    uint8_t displayUpdateTicks;
    uint8_t menuExited;
    uint8_t powerEvent;
    Settings settings;

    // Use the primary (external crystal) oscillator.
    OSCCONbits.SCS = 0;
    Settings_Load(&settings);

    /*
     * ADC setup comes in the next step. Until then all pins stay digital,
     * so the OLED and future button inputs start from a known state.
     */
    ANSEL = 0x00;
    ANSELH = 0x00;

    PORTA = 0x00;
    PORTB = 0x00;
    PORTC = 0x00;

    I2C_Init();
    ADC_Init();
    Buzzer_Init();
    Menu_Init();
    SSD1306_Init();
    SSD1306_SetContrast(settings.contrast);
    ShowStartupLogo();
    Power_Init();
    screenInitialized = 0;
    displayUpdateTicks = 0;
    signalDb = -99;
    peakDb = -99;

    while (1)
    {
        powerEvent = Power_Update((uint8_t)(PORTBbits.RB5 == 0),
                                  Menu_IsActive());

        if (powerEvent == POWER_EVENT_WOKE)
        {
            screenInitialized = 0;
            displayUpdateTicks = 0;
        }

        if (Power_DisplayIsOn())
        {
            menuExited = Menu_Update(&settings);
        }
        else
        {
            menuExited = 0;
        }

        if (menuExited)
        {
            screenInitialized = 0;
            displayUpdateTicks = 0;
        }

        if (displayUpdateTicks == 0)
        {
            batteryAdc = ADC_ReadAverage(BATTERY_ADC_CHANNEL, ADC_AVERAGE_SAMPLES);
            signalAdc = ADC_ReadAverage(SIGNAL_ADC_CHANNEL, ADC_AVERAGE_SAMPLES);

            batteryCentivolts = BatteryCentiVolts(batteryAdc);
            signalDb = AD8307dB(signalAdc);

            if (signalDb > peakDb)
            {
                peakDb = signalDb;
            }

            if (Power_DisplayIsOn() && !Menu_IsActive())
            {
                if (screenInitialized == 0)
                {
                    SSD1306_DrawMainScreen(signalDb, peakDb,
                                           SignalBarSegments(signalDb, settings.barMaxDb),
                                           batteryCentivolts, settings.beepEnabled);
                    screenInitialized = 1;
                }
                else
                {
                    SSD1306_UpdateMainScreen(signalDb, peakDb,
                                             SignalBarSegments(signalDb, settings.barMaxDb),
                                             batteryCentivolts);
                }
            }
        }

        Buzzer_Update(signalDb,
                      (uint8_t)(settings.beepEnabled && !Menu_IsActive()),
                      MAIN_LOOP_TICK_MS);

        __delay_ms(MAIN_LOOP_TICK_MS);
        displayUpdateTicks++;

        if (displayUpdateTicks >= DISPLAY_UPDATE_TICKS)
        {
            displayUpdateTicks = 0;
        }
    }
}
