#include "SSD1306.h"
#include <xc.h>
#include "i2c.h"
#define _XTAL_FREQ 20000000UL
// ======================================================
// 5x7 FONT
// ASCII 32...90
// ======================================================
static const uint8_t font5x7[][5] =
{
    {0x00,0x00,0x00,0x00,0x00}, // SPACE
    {0x00,0x00,0x5F,0x00,0x00}, // !
    {0x00,0x07,0x00,0x07,0x00}, // "
    {0x14,0x7F,0x14,0x7F,0x14}, // #
    {0x24,0x2A,0x7F,0x2A,0x12}, // $
    {0x23,0x13,0x08,0x64,0x62}, // %
    {0x36,0x49,0x55,0x22,0x50}, // &
    {0x00,0x05,0x03,0x00,0x00}, // '
    {0x00,0x1C,0x22,0x41,0x00}, // (
    {0x00,0x41,0x22,0x1C,0x00}, // )
    {0x14,0x08,0x3E,0x08,0x14}, // *
    {0x08,0x08,0x3E,0x08,0x08}, // +
    {0x00,0x50,0x30,0x00,0x00}, // ,
    {0x08,0x08,0x08,0x08,0x08}, // -
    {0x00,0x60,0x60,0x00,0x00}, // .
    {0x20,0x10,0x08,0x04,0x02}, // /

    {0x3E,0x51,0x49,0x45,0x3E}, // 0
    {0x00,0x42,0x7F,0x40,0x00}, // 1
    {0x42,0x61,0x51,0x49,0x46}, // 2
    {0x21,0x41,0x45,0x4B,0x31}, // 3
    {0x18,0x14,0x12,0x7F,0x10}, // 4
    {0x27,0x45,0x45,0x45,0x39}, // 5
    {0x3C,0x4A,0x49,0x49,0x30}, // 6
    {0x01,0x71,0x09,0x05,0x03}, // 7
    {0x36,0x49,0x49,0x49,0x36}, // 8
    {0x06,0x49,0x49,0x29,0x1E}, // 9

    {0x00,0x36,0x36,0x00,0x00}, // :
    {0x00,0x56,0x36,0x00,0x00}, // ;
    {0x08,0x14,0x22,0x41,0x00}, // <
    {0x14,0x14,0x14,0x14,0x14}, // =
    {0x00,0x41,0x22,0x14,0x08}, // >
    {0x02,0x01,0x51,0x09,0x06}, // ?
    {0x32,0x49,0x79,0x41,0x3E}, // @

    {0x7E,0x11,0x11,0x11,0x7E}, // A
    {0x7F,0x49,0x49,0x49,0x36}, // B
    {0x3E,0x41,0x41,0x41,0x22}, // C
    {0x7F,0x41,0x41,0x22,0x1C}, // D
    {0x7F,0x49,0x49,0x49,0x41}, // E
    {0x7F,0x09,0x09,0x09,0x01}, // F
    {0x3E,0x41,0x49,0x49,0x7A}, // G
    {0x7F,0x08,0x08,0x08,0x7F}, // H
    {0x00,0x41,0x7F,0x41,0x00}, // I
    {0x20,0x40,0x41,0x3F,0x01}, // J
    {0x7F,0x08,0x14,0x22,0x41}, // K
    {0x7F,0x40,0x40,0x40,0x40}, // L
    {0x7F,0x02,0x0C,0x02,0x7F}, // M
    {0x7F,0x04,0x08,0x10,0x7F}, // N
    {0x3E,0x41,0x41,0x41,0x3E}, // O
    {0x7F,0x09,0x09,0x09,0x06}, // P
    {0x3E,0x41,0x51,0x21,0x5E}, // Q
    {0x7F,0x09,0x19,0x29,0x46}, // R
    {0x46,0x49,0x49,0x49,0x31}, // S
    {0x01,0x01,0x7F,0x01,0x01}, // T
    {0x3F,0x40,0x40,0x40,0x3F}, // U
    {0x1F,0x20,0x40,0x20,0x1F}, // V
    {0x3F,0x40,0x38,0x40,0x3F}, // W
    {0x63,0x14,0x08,0x14,0x63}, // X
    {0x07,0x08,0x70,0x08,0x07}, // Y
    {0x61,0x51,0x49,0x45,0x43}  // Z
};

/* A mertekegyseghez kell egyetlen kisbetu is: dB. */
static const uint8_t font5x7_lower_d[5] =
{
    0x38, 0x44, 0x44, 0x7F, 0x40
};

static const uint8_t *SSD1306_GetGlyph(char c)
{
    if (c == 'd')
    {
        return font5x7_lower_d;
    }

    if ((c < 32) || (c > 90))
    {
        return font5x7[0];
    }

    return font5x7[(uint8_t)c - 32];
}

/* Egy osszefuggo I2C adatblokk a grafikus elemek gyors rajzolasahoz. */
static void SSD1306_WriteSpan(uint8_t x, uint8_t page,
                              const uint8_t *data, uint8_t length)
{
    uint8_t i;

    SSD1306_SetPosition(x, page);
    I2C_Start();
    I2C_Write(SSD1306_ADDR << 1);
    I2C_Write(SSD1306_DATA);

    for (i = 0; i < length; i++)
    {
        I2C_Write(data[i]);
    }

    I2C_Stop();
}

void SSD1306_Init(void)
{
    __delay_ms(100);

    SSD1306_Command(0xAE);       // Kijelz? KIKAPCSOLÁSA (Alvó mód)
    
    SSD1306_Command(0xD5);       // Órajel osztás és frekvencia beállítása
    SSD1306_Command(0x80);       // SSD1306 gyári ajánlott érték (Fels? 4 bit: frekvencia, alsó 4 bit: osztó)

    SSD1306_Command(0xA8);       // Multiplexelési arány beállítása (Sorok száma)
    SSD1306_Command(0x3F);       // 64 sor (128x64-es kijelz?höz)

    SSD1306_Command(0xD3);       // Kijelz? függ?leges eltolása (Display Offset)
    SSD1306_Command(0x00);       // Nincs eltolás

    SSD1306_Command(0x40);       // Megjelenítés kezd?sorának beállítása (RAM 0. sor)

    // --- KRITIKUS VÁLTOZTATÁS AZ SSD1306-HOZ ---
    SSD1306_Command(0x8D);       // SSD1306 Charge Pump (DC-DC konverter) vezérlés parancsa (SH1106-nál ez 0xAD volt)
    SSD1306_Command(0x14);       // 0x14 = BEKAPCSOLVA (0x10 lenne a kikapcsolva)
    // -------------------------------------------

    SSD1306_Command(0xA1);       // Szegmens újra-hozzárendelés megfordítva (Vízszintes tükrözés/forgatás)
    SSD1306_Command(0xC8);       // COM kimeneti pásztázási irány megfordítva (Függ?leges tükrözés/forgatás)

    SSD1306_Command(0x20);       // Címzési mód kiválasztása (Memory Addressing Mode - SSD1306 specifikus)
    SSD1306_Command(0x02);       // 0x02 = Oldal címzési mód (Page Addressing Mode - ez egyezik meg az SH1106 m?ködésével)

    SSD1306_Command(0xDA);       // COM hardveres konfiguráció
    SSD1306_Command(0x12);       // Alternatív pin konfiguráció (128x64-es kijelz?höz)

    SSD1306_SetContrast(0x60);

    SSD1306_Command(0xD9);       // El?töltési periódus (Pre-charge period) hossza
    SSD1306_Command(0x22);       // Gyári alapérték

    SSD1306_Command(0xDB);       // VCOMH feszültségszint kiválasztása
    SSD1306_Command(0x20);       // SSD1306 gyári ajánlott érték (~0.77 x Vcc)

    SSD1306_Command(0xA4);       // Kijelz? RAM követése (Normál m?ködés)
    SSD1306_Command(0xA6);       // Normál színmód (Nincs invertálás)
    
    SSD1306_Command(0xAF);       // Kijelz? BEKAPCSOLÁSA (Az inicializálás végén életre keltjük)
}






// ======================================================
// I2C Alapm?veletek
// ======================================================
void SSD1306_Command(uint8_t command)
{
    I2C_Start();
    I2C_Write(SSD1306_ADDR << 1);
    I2C_Write(SSD1306_CMD);
    I2C_Write(command);
    I2C_Stop();
}

void SSD1306_SetContrast(uint8_t contrast)
{
    SSD1306_Command(0x81);
    SSD1306_Command(contrast);
}

void SSD1306_DisplayOn(void)
{
    SSD1306_Command(0xAF);
}

void SSD1306_DisplayOff(void)
{
    SSD1306_Command(0xAE);
}

void SSD1306_Data(uint8_t data)
{
    I2C_Start();
    I2C_Write(SSD1306_ADDR << 1);   // I2C cím + WRITE
    I2C_Write(SSD1306_DATA);        // adat mód (0x40)
    I2C_Write(data);               // pixeladat
    I2C_Stop();
}

// ======================================================
// Pozicionálás (Áthelyezve a Char() elé, hogy látható legyen!)
// ======================================================
void SSD1306_SetPosition(uint8_t x, uint8_t page)
{
    //x += 2; // SSD1306 RAM korrekció

    SSD1306_Command(0xB0 | page);
    SSD1306_Command(0x00 | (x & 0x0F));
    SSD1306_Command(0x10 | ((x >> 4) & 0x0F));
}

// ======================================================
// Grafika és Karakter megjelenítés
// ======================================================
void SSD1306_Char(uint8_t x, uint8_t page, char c)
{
    uint8_t i;
    const uint8_t *glyph;

    glyph = SSD1306_GetGlyph(c);

    SSD1306_SetPosition(x, page);

    for (i = 0; i < 5; i++)
    {
        SSD1306_Data(glyph[i]);
    }

    SSD1306_Data(0x00); // 1 pixel üres hely a karakterek között
}

/* Az 5x7-es betu 2x meretben 10x14 pixel, ket kijelzooldalon. */
void SSD1306_LargeChar(uint8_t x, uint8_t page, char c)
{
    uint8_t i;
    uint8_t bit;
    uint8_t topColumn;
    uint8_t bottomColumn;
    uint8_t top[12];
    uint8_t bottom[12];
    const uint8_t *glyph;

    if (page > 6)
    {
        return;
    }

    glyph = SSD1306_GetGlyph(c);

    for (i = 0; i < 5; i++)
    {
        topColumn = 0x00;
        bottomColumn = 0x00;

        for (bit = 0; bit < 4; bit++)
        {
            if (glyph[i] & ((uint8_t)1U << bit))
            {
                topColumn |= ((uint8_t)0x03U << (bit * 2));
            }
        }

        for (bit = 4; bit < 7; bit++)
        {
            if (glyph[i] & ((uint8_t)1U << bit))
            {
                bottomColumn |= ((uint8_t)0x03U << ((bit - 4) * 2));
            }
        }

        top[i * 2] = topColumn;
        top[(i * 2) + 1] = topColumn;
        bottom[i * 2] = bottomColumn;
        bottom[(i * 2) + 1] = bottomColumn;
    }

    /* Ket pixel ures hely a nagy karakterek kozott. */
    top[10] = 0x00;
    top[11] = 0x00;
    bottom[10] = 0x00;
    bottom[11] = 0x00;

    SSD1306_WriteSpan(x, page, top, 12);
    SSD1306_WriteSpan(x, page + 1, bottom, 12);
}

void SSD1306_LargeString(uint8_t x, uint8_t page, const char *text)
{
    while ((*text != '\0') && (x <= 116))
    {
        SSD1306_LargeChar(x, page, *text);

        if (x > 104)
        {
            break;
        }

        x += 12;
        text++;
    }
}

void SSD1306_String(uint8_t x, uint8_t page, const char *text)
{
    while (*text)
    {
        SSD1306_Char(x, page, *text);

        x += 6;
        text++;

        if (x > 122)
        {
            break;
        }
    }
}

void SSD1306_WritePage(uint8_t page, uint8_t pattern)
{
    uint8_t x;

    SSD1306_SetPosition(0, page);

    I2C_Start();
    I2C_Write(SSD1306_ADDR << 1);
    I2C_Write(SSD1306_DATA);

    for (x = 0; x < 128; x++)
    {
        I2C_Write(pattern);
    }

    I2C_Stop();
}

void SSD1306_DrawBitmap(const uint8_t *data)
{
    uint8_t page;
    uint8_t x;

    for (page = 0; page < 8; page++)
    {
        SSD1306_SetPosition(0, page);

        I2C_Start();
        I2C_Write(SSD1306_ADDR << 1);
        I2C_Write(SSD1306_DATA);

        for (x = 0; x < 128; x++)
        {
            I2C_Write(data[((uint16_t)page * 128U) + x]);
        }

        I2C_Stop();
    }
}

void SSD1306_Clear(void)
{
    uint8_t page;

    for (page = 0; page < 8; page++)
    {
        SSD1306_WritePage(page, 0x00);
    }
}

// Megmaradt üres függvények, hogy a .h deklaráció meglegyen
// ------------------------------------------------------
// Tesztminta
// ------------------------------------------------------

/* 12 darab, egyenkent 8x12 pixeles keretes jelszint-szegmens. */
void SSD1306_DrawSignalBar(uint8_t activeSegments)
{
    uint8_t segment;
    uint8_t column;
    uint8_t x;
    uint8_t top[8];
    uint8_t bottom[8];

    if (activeSegments > 12)
    {
        activeSegments = 12;
    }

    for (segment = 0; segment < 12; segment++)
    {
        for (column = 0; column < 8; column++)
        {
            if (segment < activeSegments)
            {
                top[column] = 0xFF;
                bottom[column] = 0x0F;
            }
            else if ((column == 0) || (column == 7))
            {
                top[column] = 0xFF;
                bottom[column] = 0x0F;
            }
            else
            {
                top[column] = 0x01;
                bottom[column] = 0x08;
            }
        }

        x = 4 + (segment * 10);
        SSD1306_WriteSpan(x, 4, top, 8);
        SSD1306_WriteSpan(x, 5, bottom, 8);
    }
}

void SSD1306_DrawMainScreen(int8_t signalDb, int8_t peakDb, uint8_t activeSegments,
                            uint16_t batteryCentivolts, uint8_t beepOn)
{
    SSD1306_Clear();
    SSD1306_String(28, 0, "SIGNAL LEVEL");
    SSD1306_String(86, 3, "dB");

    if (beepOn)
    {
        SSD1306_String(86, 7, "BEEP ON");
    }
    else
    {
        SSD1306_String(80, 7, "BEEP OFF");
    }

    SSD1306_UpdateMainScreen(signalDb, peakDb, activeSegments, batteryCentivolts);
}

void SSD1306_UpdateMainScreen(int8_t signalDb, int8_t peakDb, uint8_t activeSegments,
                              uint16_t batteryCentivolts)
{
    uint8_t magnitude;
    uint8_t wholeVolts;
    uint8_t decimalPart;
    char dbText[4];
    char batteryText[11];
    char peakText[11];

    /* Az elso ADC-kalibracio elott is legyen ertelmes hatartartas. */
    if (signalDb > 0)
    {
        signalDb = 0;
    }
    else if (signalDb < -99)
    {
        signalDb = -99;
    }

    magnitude = (uint8_t)(-signalDb);
    dbText[0] = '-';
    dbText[1] = (char)('0' + (magnitude / 10));
    dbText[2] = (char)('0' + (magnitude % 10));
    dbText[3] = '\0';

    if (peakDb > 0)
    {
        peakDb = 0;
    }
    else if (peakDb < -99)
    {
        peakDb = -99;
    }

    magnitude = (uint8_t)(-peakDb);
    peakText[0] = 'P';
    peakText[1] = 'E';
    peakText[2] = 'A';
    peakText[3] = 'K';
    peakText[4] = ' ';
    peakText[5] = '-';
    peakText[6] = (char)('0' + (magnitude / 10U));
    peakText[7] = (char)('0' + (magnitude % 10U));
    peakText[8] = 'd';
    peakText[9] = 'B';
    peakText[10] = '\0';

    wholeVolts = (uint8_t)(batteryCentivolts / 100U);
    decimalPart = (uint8_t)(batteryCentivolts % 100U);

    batteryText[0] = 'B';
    batteryText[1] = 'A';
    batteryText[2] = 'T';
    batteryText[3] = ' ';

    if (wholeVolts >= 10)
    {
        batteryText[4] = (char)('0' + (wholeVolts / 10));
        batteryText[5] = (char)('0' + (wholeVolts % 10));
        batteryText[6] = '.';
        batteryText[7] = (char)('0' + (decimalPart / 10));
        batteryText[8] = (char)('0' + (decimalPart % 10));
        batteryText[9] = 'V';
        batteryText[10] = '\0';
    }
    else
    {
        batteryText[4] = (char)('0' + wholeVolts);
        batteryText[5] = '.';
        batteryText[6] = (char)('0' + (decimalPart / 10));
        batteryText[7] = (char)('0' + (decimalPart % 10));
        batteryText[8] = 'V';
        batteryText[9] = '\0';
    }

    /* Fixed-width fields overwrite their own pixels; clearing first would blink. */
    SSD1306_String(34, 1, peakText);
    SSD1306_LargeString(46, 2, dbText);
    SSD1306_DrawSignalBar(activeSegments);
    SSD1306_String(0, 7, batteryText);
}
