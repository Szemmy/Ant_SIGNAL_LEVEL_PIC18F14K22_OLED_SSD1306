#ifndef BUZZER_H
#define BUZZER_H

#include <stdint.h>

void Buzzer_Init(void);
void Buzzer_Silence(void);
void Buzzer_Update(int8_t signalDb, uint8_t enabled, uint16_t elapsedMs);

#endif /* BUZZER_H */
