#include <xc.h>
#include <stdint.h>
#include "menu.h"
#include "SSD1306.h"
#include "settings.h"

#define BUTTON_DEBOUNCE_TICKS 3U
#define MENU_LONG_PRESS_TICKS 120U

typedef struct
{
    uint8_t candidate;
    uint8_t stable;
    uint8_t debounceTicks;
} ButtonState;

typedef enum
{
    MENU_PAGE_CONTRAST = 0,
    MENU_PAGE_BEEP,
    MENU_PAGE_BAR_MAX
} MenuPage;

static ButtonState menuButton;
static ButtonState upButton;
static ButtonState downButton;
static uint8_t menuActive;
static uint8_t menuLongPressTicks;
static MenuPage menuPage;

static uint8_t Button_Pressed(ButtonState *button, uint8_t rawPressed)
{
    if (rawPressed != button->candidate)
    {
        button->candidate = rawPressed;
        button->debounceTicks = 0;
    }
    else if (button->debounceTicks < BUTTON_DEBOUNCE_TICKS)
    {
        button->debounceTicks++;

        if ((button->debounceTicks == BUTTON_DEBOUNCE_TICKS) &&
            (button->stable != button->candidate))
        {
            button->stable = button->candidate;

            if (button->stable)
            {
                return 1;
            }
        }
    }

    return 0;
}

static void UInt8Text(uint8_t value, char *text)
{
    if (value >= 100U)
    {
        text[0] = (char)('0' + (value / 100U));
        text[1] = (char)('0' + ((value / 10U) % 10U));
        text[2] = (char)('0' + (value % 10U));
        text[3] = '\0';
    }
    else
    {
        text[0] = (char)('0' + (value / 10U));
        text[1] = (char)('0' + (value % 10U));
        text[2] = '\0';
    }
}

static void DbText(int8_t value, char *text)
{
    uint8_t magnitude;

    if (value > 0)
    {
        value = 0;
    }
    else if (value < -99)
    {
        value = -99;
    }

    magnitude = (uint8_t)(-value);
    text[0] = '-';
    text[1] = (char)('0' + (magnitude / 10U));
    text[2] = (char)('0' + (magnitude % 10U));
    text[3] = 'D';
    text[4] = 'B';
    text[5] = '\0';
}

static void Menu_Draw(const Settings *settings)
{
    char valueText[6];

    SSD1306_Clear();

    if (menuPage == MENU_PAGE_CONTRAST)
    {
        UInt8Text(settings->contrast, valueText);
        SSD1306_String(34, 0, "MENU 1/3");
        SSD1306_String(28, 2, "CONTRAST");
        SSD1306_String(55, 4, valueText);
    }
    else if (menuPage == MENU_PAGE_BEEP)
    {
        SSD1306_String(34, 0, "MENU 2/3");
        SSD1306_String(52, 2, "BEEP");

        if (settings->beepEnabled)
        {
            SSD1306_String(52, 4, "ON");
        }
        else
        {
            SSD1306_String(49, 4, "OFF");
        }
    }
    else
    {
        DbText(settings->barMaxDb, valueText);
        SSD1306_String(34, 0, "MENU 3/3");
        SSD1306_String(43, 2, "BAR MAX");
        SSD1306_String(49, 4, valueText);
    }

    SSD1306_String(22, 6, "UP DOWN CHANGE");
    SSD1306_String(37, 7, "MENU NEXT");
}

static void Menu_Enter(const Settings *settings)
{
    menuActive = 1;
    menuPage = MENU_PAGE_CONTRAST;
    Menu_Draw(settings);
}

static uint8_t Menu_Next(Settings *settings)
{
    if (menuPage == MENU_PAGE_BAR_MAX)
    {
        Settings_Save(settings);
        menuActive = 0;
        return 1;
    }

    menuPage = (MenuPage)(menuPage + 1);
    Menu_Draw(settings);
    return 0;
}

static void Menu_Adjust(Settings *settings, uint8_t upPressed, uint8_t downPressed)
{
    uint8_t changed;

    changed = 0;

    if (menuPage == MENU_PAGE_CONTRAST)
    {
        if (upPressed && (settings->contrast < 160U))
        {
            settings->contrast += 16U;
            changed = 1;
        }
        else if (downPressed && (settings->contrast > 32U))
        {
            settings->contrast -= 16U;
            changed = 1;
        }

        if (changed)
        {
            SSD1306_SetContrast(settings->contrast);
        }
    }
    else if (menuPage == MENU_PAGE_BEEP)
    {
        if (upPressed && !settings->beepEnabled)
        {
            settings->beepEnabled = 1;
            changed = 1;
        }
        else if (downPressed && settings->beepEnabled)
        {
            settings->beepEnabled = 0;
            changed = 1;
        }
    }
    else
    {
        if (upPressed && (settings->barMaxDb < 0))
        {
            settings->barMaxDb += 5;
            changed = 1;
        }
        else if (downPressed && (settings->barMaxDb > -30))
        {
            settings->barMaxDb -= 5;
            changed = 1;
        }
    }

    if (changed)
    {
        Menu_Draw(settings);
    }
}

void Menu_Init(void)
{
    TRISBbits.TRISB5 = 1;
    TRISCbits.TRISC5 = 1;
    TRISCbits.TRISC7 = 1;

    INTCON2bits.NOT_RABPU = 0;
    WPUBbits.WPUB5 = 1;

    menuButton.candidate = 0;
    menuButton.stable = 0;
    menuButton.debounceTicks = 0;
    upButton.candidate = 0;
    upButton.stable = 0;
    upButton.debounceTicks = 0;
    downButton.candidate = 0;
    downButton.stable = 0;
    downButton.debounceTicks = 0;

    menuActive = 0;
    menuLongPressTicks = 0;
    menuPage = MENU_PAGE_CONTRAST;
}

uint8_t Menu_Update(Settings *settings)
{
    uint8_t menuPressed;
    uint8_t upPressed;
    uint8_t downPressed;

    menuPressed = Button_Pressed(&menuButton, (PORTBbits.RB5 == 0));
    upPressed = Button_Pressed(&upButton, (PORTCbits.RC7 == 0));
    downPressed = Button_Pressed(&downButton, (PORTCbits.RC5 == 0));

    if (!menuActive)
    {
        if (menuButton.stable)
        {
            if (menuLongPressTicks < MENU_LONG_PRESS_TICKS)
            {
                menuLongPressTicks++;

                if (menuLongPressTicks == MENU_LONG_PRESS_TICKS)
                {
                    Menu_Enter(settings);
                }
            }
        }
        else
        {
            menuLongPressTicks = 0;
        }

        return 0;
    }

    if (menuPressed)
    {
        return Menu_Next(settings);
    }

    Menu_Adjust(settings, upPressed, downPressed);
    return 0;
}

uint8_t Menu_IsActive(void)
{
    return menuActive;
}
