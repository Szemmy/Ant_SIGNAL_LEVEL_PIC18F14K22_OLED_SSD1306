#include <xc.h>
#include <stdint.h>
#include "power.h"
#include "SSD1306.h"
#include "buzzer.h"

#define _XTAL_FREQ             20000000UL
#define POWER_TICK_MS          10U
#define OLED_OFF_TICKS         (300000UL / POWER_TICK_MS)
#define PIC_SLEEP_TICKS        (600000UL / POWER_TICK_MS)
#define MENU_WAKE_DEBOUNCE_TICKS 3U
#define MENU_SLEEP_VERIFY_MS   25U
#define AD8307_ENABLE_SETTLE_MS 5U

static uint16_t inactivityTicks;
static uint8_t displayIsOn;
static uint8_t menuButtonHeldTicks;

/* RC1 drives the AD8307 ENB input: high = measure, low = standby. */
static void Power_AD8307_Init(void)
{
    ANSELbits.ANS5 = 0;
    LATCbits.LATC1 = 0;
    TRISCbits.TRISC1 = 0;
}

static void Power_AD8307_Enable(void)
{
    LATCbits.LATC1 = 1;
    __delay_ms(AD8307_ENABLE_SETTLE_MS);
}

static void Power_AD8307_Disable(void)
{
    LATCbits.LATC1 = 0;
}

static void Power_ClearPortBChange(void)
{
    uint8_t portBRead;

    portBRead = PORTB;
    (void)portBRead;
    INTCONbits.RBIF = 0;
}

static uint8_t Power_MenuButtonDebounced(uint8_t menuButtonHeld)
{
    if (menuButtonHeld)
    {
        if (menuButtonHeldTicks < MENU_WAKE_DEBOUNCE_TICKS)
        {
            menuButtonHeldTicks++;
        }
    }
    else
    {
        menuButtonHeldTicks = 0;
    }

    return (menuButtonHeldTicks >= MENU_WAKE_DEBOUNCE_TICKS);
}

static uint8_t Power_MenuStillPressed(void)
{
    /* Reject a very short Port-B wake-up pulse before lighting the OLED. */
    __delay_ms(MENU_SLEEP_VERIFY_MS);
    return (PORTBbits.RB5 == 0);
}

static void Power_SleepUntilMenu(void)
{
    /* RB5 is the MENU key and is the only enabled wake-up source. */
    Buzzer_Silence();
    Power_AD8307_Disable();

    while (1)
    {
        IOCB = 0x00;
        IOCBbits.IOCB5 = 1;
        Power_ClearPortBChange();

        /* No interrupt routine is used: RB5 wakes execution after SLEEP. */
        INTCONbits.GIE = 0;
        INTCONbits.RBIE = 1;
        SLEEP();
        NOP();

        INTCONbits.RBIE = 0;
        Power_ClearPortBChange();

        if (Power_MenuStillPressed())
        {
            Power_AD8307_Enable();
            return;
        }
    }
}

void Power_Init(void)
{
    Power_AD8307_Init();
    Power_AD8307_Enable();
    inactivityTicks = 0;
    displayIsOn = 1;
    menuButtonHeldTicks = 0;
}

uint8_t Power_Update(uint8_t menuButtonHeld, uint8_t menuActive)
{
    if (Power_MenuButtonDebounced(menuButtonHeld) || menuActive)
    {
        inactivityTicks = 0;

        if (!displayIsOn)
        {
            SSD1306_DisplayOn();
            displayIsOn = 1;
            return POWER_EVENT_WOKE;
        }

        return POWER_EVENT_NONE;
    }

    if (inactivityTicks < PIC_SLEEP_TICKS)
    {
        inactivityTicks++;
    }

    if (displayIsOn && (inactivityTicks >= OLED_OFF_TICKS))
    {
        SSD1306_DisplayOff();
        displayIsOn = 0;
    }

    if (inactivityTicks >= PIC_SLEEP_TICKS)
    {
        Power_SleepUntilMenu();
        SSD1306_DisplayOn();
        displayIsOn = 1;
        inactivityTicks = 0;
        return POWER_EVENT_WOKE;
    }

    return POWER_EVENT_NONE;
}

uint8_t Power_DisplayIsOn(void)
{
    return displayIsOn;
}
