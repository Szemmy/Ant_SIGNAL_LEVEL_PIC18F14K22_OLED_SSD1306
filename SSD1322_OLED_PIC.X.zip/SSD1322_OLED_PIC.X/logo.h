#ifndef LOGO_H
#define LOGO_H

void Logo_Draw(void);

#endif /* LOGO_H */
