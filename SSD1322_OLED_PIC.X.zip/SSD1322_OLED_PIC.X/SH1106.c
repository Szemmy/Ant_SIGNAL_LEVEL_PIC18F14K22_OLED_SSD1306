#include "SH1106.h"
#include <xc.h>
#include "i2c.h"
#define _XTAL_FREQ 20000000UL
// ======================================================
// 5x7 FONT
// ASCII 32...90
// ======================================================
const uint8_t font5x7[][5] =
{
    {0x00,0x00,0x00,0x00,0x00}, // SPACE
    {0x00,0x00,0x5F,0x00,0x00}, // !
    {0x00,0x07,0x00,0x07,0x00}, // "
    {0x14,0x7F,0x14,0x7F,0x14}, // #
    {0x24,0x2A,0x7F,0x2A,0x12}, // $
    {0x23,0x13,0x08,0x64,0x62}, // %
    {0x36,0x49,0x55,0x22,0x50}, // &
    {0x00,0x05,0x03,0x00,0x00}, // '
    {0x00,0x1C,0x22,0x41,0x00}, // (
    {0x00,0x41,0x22,0x1C,0x00}, // )
    {0x14,0x08,0x3E,0x08,0x14}, // *
    {0x08,0x08,0x3E,0x08,0x08}, // +
    {0x00,0x50,0x30,0x00,0x00}, // ,
    {0x08,0x08,0x08,0x08,0x08}, // -
    {0x00,0x60,0x60,0x00,0x00}, // .
    {0x20,0x10,0x08,0x04,0x02}, // /

    {0x3E,0x51,0x49,0x45,0x3E}, // 0
    {0x00,0x42,0x7F,0x40,0x00}, // 1
    {0x42,0x61,0x51,0x49,0x46}, // 2
    {0x21,0x41,0x45,0x4B,0x31}, // 3
    {0x18,0x14,0x12,0x7F,0x10}, // 4
    {0x27,0x45,0x45,0x45,0x39}, // 5
    {0x3C,0x4A,0x49,0x49,0x30}, // 6
    {0x01,0x71,0x09,0x05,0x03}, // 7
    {0x36,0x49,0x49,0x49,0x36}, // 8
    {0x06,0x49,0x49,0x29,0x1E}, // 9

    {0x00,0x36,0x36,0x00,0x00}, // :
    {0x00,0x56,0x36,0x00,0x00}, // ;
    {0x08,0x14,0x22,0x41,0x00}, // <
    {0x14,0x14,0x14,0x14,0x14}, // =
    {0x00,0x41,0x22,0x14,0x08}, // >
    {0x02,0x01,0x51,0x09,0x06}, // ?
    {0x32,0x49,0x79,0x41,0x3E}, // @

    {0x7E,0x11,0x11,0x11,0x7E}, // A
    {0x7F,0x49,0x49,0x49,0x36}, // B
    {0x3E,0x41,0x41,0x41,0x22}, // C
    {0x7F,0x41,0x41,0x22,0x1C}, // D
    {0x7F,0x49,0x49,0x49,0x41}, // E
    {0x7F,0x09,0x09,0x09,0x01}, // F
    {0x3E,0x41,0x49,0x49,0x7A}, // G
    {0x7F,0x08,0x08,0x08,0x7F}, // H
    {0x00,0x41,0x7F,0x41,0x00}, // I
    {0x20,0x40,0x41,0x3F,0x01}, // J
    {0x7F,0x08,0x14,0x22,0x41}, // K
    {0x7F,0x40,0x40,0x40,0x40}, // L
    {0x7F,0x02,0x0C,0x02,0x7F}, // M
    {0x7F,0x04,0x08,0x10,0x7F}, // N
    {0x3E,0x41,0x41,0x41,0x3E}, // O
    {0x7F,0x09,0x09,0x09,0x06}, // P
    {0x3E,0x41,0x51,0x21,0x5E}, // Q
    {0x7F,0x09,0x19,0x29,0x46}, // R
    {0x46,0x49,0x49,0x49,0x31}, // S
    {0x01,0x01,0x7F,0x01,0x01}, // T
    {0x3F,0x40,0x40,0x40,0x3F}, // U
    {0x1F,0x20,0x40,0x20,0x1F}, // V
    {0x3F,0x40,0x38,0x40,0x3F}, // W
    {0x63,0x14,0x08,0x14,0x63}, // X
    {0x07,0x08,0x70,0x08,0x07}, // Y
    {0x61,0x51,0x49,0x45,0x43}  // Z
};

void SH1106_Init(void)
{
    __delay_ms(100);

    SH1106_Command(0xAE);       //kijelz? be--0xAE KI.
                                //0xA5: �sszes pixel BE (A RAM tartalm�t�l f�ggetlen�l minden k�ppont vil�g�t).
                                //0xA6: Norm�l kijelz�s (A mem�ri�ban l�v? 1-es bit vil�g�t, a 0 s�t�t).
                                //0xA7: Invert�lt kijelz�s (A mem�ri�ban l�v? 0-s bit vil�g�t, az 1-es s�t�t).
                                //0xDA + [0x02, 0x12]: COM hardveres konfigur�ci� (0x02 = Szekvenci�lis, 0x12 = Alternat�v pinek).
                                //0xDB + [0x00 ? 0xFF]: VCOMH fesz�lts�gszint kiv�laszt�sa (A k�z�s elektr�da fesz�lts�ge).
                                /*Kijelz? orient�ci� (Forgat�s)0xA0: Szegmens �jra-hozz�rendel�s norm�l m�d 
                                 * (Oszlop 0 a SEG0-ra k�pez?dik le).0xA1: Szegmens �jra-hozz�rendel�s megford�tva 
                                 * (Oszlop 131 a SEG0-ra k�pez?dik le -> V�zszintes t�kr�z�s).
                                 * 0xC0: COM kimeneti p�szt�z�si ir�ny norm�l m�d (COM0-t�l COM[N-1]-ig).
                                 * 0xC8: COM kimeneti p�szt�z�si ir�ny megford�tva (COM[N-1]-t?l COM0-ig -> F�gg?leges t�kr�z�s).*/
                                /*C�mz�s �s pozicion�l�s0x00 ? 0x0F: Oszlopc�m als� 4 bitj�nek be�ll�t�sa 
                                 * (0x00-t�l 0x0F-ig).0x10 ? 0x1F: Oszlopc�m fels? 4 bitj�nek be�ll�t�sa 
                                 * (0x10-t?l 0x1F-ig).0xB0 ? 0xB7: Oldalc�m (Page) be�ll�t�sa (0xB0-t�l 0xB7-ig,
                                 *  ahol a kijelz? 8 oldalra van osztva f�gg?legesen).0x40 ? 0x7F: 
                                 * Megjelen�t�s kezd?sor�nak be�ll�t�sa (0x40-t?l 0x7F-ig, ami a RAM 0?63. sor�nak felel meg).*/
    
    SH1106_Command(0xD5);       //�rajel oszt�s �s frekvencia. als� 4 bit oszt�, fels? 4 bit frekvencia. 0x00-0xFF
    SH1106_Command(0x80);       

    SH1106_Command(0xA8);       //0xA8 + [0x00 ? 0x3F]: Multiplexel�si ar�ny be�ll�t�sa (Kijelz? sorok sz�ma: 1-t?l 64-ig).
    SH1106_Command(0x3F);

    SH1106_Command(0xD3);       //0xD3 + [0x00 ? 0x3F]: Kijelz? eltol�sa (Display Offset, f�gg?leges eltol�s 0-t�l 63 sorig).
    SH1106_Command(0x00);

    SH1106_Command(0x40);       //0x40 ? 0x7F: Megjelen�t�s kezd?sor�nak be�ll�t�sa (0x40-t?l 0x7F-ig, ami a RAM 0?63. sor�nak felel meg).

    SH1106_Command(0xAD);       //0xAD + [0x8A, 0x8B]: Be�p�tett DC-DC konverter �llapot�nak be�ll�t�sa (0x8A = KIKAPCSOLVA, 0x8B = BEKAPCSOLVA).
    SH1106_Command(0x8B);

    SH1106_Command(0xA1);       //0xA1: Szegmens �jra-hozz�rendel�s megford�tva (Oszlop 131 a SEG0-ra k�pez?dik le -> V�zszintes t�kr�z�s).
    SH1106_Command(0xC8);

    SH1106_Command(0xDA);       //0xDA + [0x02, 0x12]: COM hardveres konfigur�ci� (0x02 = Szekvenci�lis, 0x12 = Alternat�v pinek).
    SH1106_Command(0x12);

    SH1106_Command(0x81);       //0x81 + [0x00 ? 0xFF]: Kontraszt be�ll�t�sa (A f�nyer? sk�l�ja 0-t�l 255-ig terjed).
    SH1106_Command(0x60);

    SH1106_Command(0xD9);       //0xD9 + [0x00 ? 0xFF]: T�lt�si peri�dusok (Pre-charge period) hossza (Als� 4 bit f�zis 1, fels? 4 bit f�zis 2).
    SH1106_Command(0x22);

    SH1106_Command(0xDB);       //0xDB + [0x00 ? 0xFF]: VCOMH fesz�lts�gszint kiv�laszt�sa (A k�z�s elektr�da fesz�lts�ge).
    SH1106_Command(0x35);

    SH1106_Command(0xA4);       //0xA4: Kijelz? RAM k�vet�se (Norm�l m?k�d�s, a mem�ri�t jelen�ti meg).
    SH1106_Command(0xA6);

    /*
     * M�g kikapcsolt OLED mellett t�rl�nk,
     * �gy nem l�tszik a bekapcsol�si "k�sa".
     */
    SH1106_Clear();

    SH1106_Command(0xAF);

    __delay_ms(10);
}






// ======================================================
// I2C Alapm?veletek
// ======================================================
void SH1106_Command(uint8_t command)
{
    I2C_Start();
    I2C_Write(SH1106_ADDR << 1);
    I2C_Write(SH1106_CMD);
    I2C_Write(command);
    I2C_Stop();
}

void SH1106_Data(uint8_t data)
{
    I2C_Start();
    I2C_Write(SH1106_ADDR << 1);   // I2C c�m + WRITE
    I2C_Write(SH1106_DATA);        // adat m�d (0x40)
    I2C_Write(data);               // pixeladat
    I2C_Stop();
}

// ======================================================
// Pozicion�l�s (�thelyezve a Char() el�, hogy l�that� legyen!)
// ======================================================
void SH1106_SetPosition(uint8_t x, uint8_t page)
{
    x += 2; // SH1106 RAM korrekci�

    SH1106_Command(0xB0 | page);
    SH1106_Command(0x00 | (x & 0x0F));
    SH1106_Command(0x10 | ((x >> 4) & 0x0F));
}

// ======================================================
// Grafika �s Karakter megjelen�t�s
// ======================================================
void SH1106_Char(uint8_t x, uint8_t page, char c)
{
    uint8_t i;
    uint8_t index;

    if (c < 32 || c > 90)
    {
        c = ' ';
    }

    index = (uint8_t)c - 32;

    SH1106_SetPosition(x, page);

    for (i = 0; i < 5; i++)
    {
        SH1106_Data(font5x7[index][i]);
    }

    SH1106_Data(0x00); // 1 pixel �res hely a karakterek k�z�tt
}

void SH1106_String(uint8_t x, uint8_t page, const char *text)
{
    while (*text)
    {
        SH1106_Char(x, page, *text);

        x += 6;
        text++;

        if (x > 122)
        {
            break;
        }
    }
}

void SH1106_WritePage(uint8_t page, uint8_t pattern)
{
    uint8_t x;

    SH1106_SetPosition(0, page);

    I2C_Start();
    I2C_Write(SH1106_ADDR << 1);
    I2C_Write(SH1106_DATA);

    for (x = 0; x < 128; x++)
    {
        I2C_Write(pattern);
    }

    I2C_Stop();
}

void SH1106_Clear(void)
{
    uint8_t page;

    for (page = 0; page < 8; page++)
    {
        SH1106_WritePage(page, 0x00);
    }
}

// Megmaradt �res f�ggv�nyek, hogy a .h deklar�ci� meglegyen
void SH1106_Fill(uint8_t pattern)
{
    uint8_t page;
    uint8_t x;

    for (page = 0; page < 8; page++)
    {
        SH1106_SetPosition(0, page);

        for (x = 0; x < 128; x++)
        {
            SH1106_Data(pattern);
        }
    }
}

// ------------------------------------------------------
// Tesztminta
// ------------------------------------------------------

void SH1106_TestPattern(void)
{
    uint8_t page;

    for (page = 0; page < 8; page++)
    {
        if (page & 1)
        {
            SH1106_WritePage(page, 0xAA);
        }
        else
        {
            SH1106_WritePage(page, 0x55);
        }
    }
}