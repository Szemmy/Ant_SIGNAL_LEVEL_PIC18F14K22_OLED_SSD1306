#ifndef I2C_H
#define	I2C_H

#include <xc.h>        // Regiszterek miatt
#include <stdint.h>    // uint8_t miatt

// I2C F�ggv�nyek deklar�ci�i
void I2C_Init(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_Write(uint8_t data);

#endif	/* I2C_H */