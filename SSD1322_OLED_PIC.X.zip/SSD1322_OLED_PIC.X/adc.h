#ifndef ADC_H
#define ADC_H

#include <stdint.h>

void ADC_Init(void);
uint16_t ADC_Read(uint8_t channel);
uint16_t ADC_ReadAverage(uint8_t channel, uint8_t samples);

#endif /* ADC_H */
