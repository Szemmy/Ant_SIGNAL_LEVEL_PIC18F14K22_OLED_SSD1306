#ifndef SSD1306_H
#define SSD1306_H

#include <xc.h>
#include <stdint.h>

#define SSD1306_ADDR 0x3C
#define SSD1306_CMD  0x00
#define SSD1306_DATA 0x40

void SSD1306_Init(void);
void SSD1306_Command(uint8_t command);
void SSD1306_SetContrast(uint8_t contrast);
void SSD1306_DisplayOn(void);
void SSD1306_DisplayOff(void);
void SSD1306_Data(uint8_t data);
void SSD1306_SetPosition(uint8_t x, uint8_t page);
void SSD1306_Char(uint8_t x, uint8_t page, char c);
void SSD1306_String(uint8_t x, uint8_t page, const char *text);
void SSD1306_LargeChar(uint8_t x, uint8_t page, char c);
void SSD1306_LargeString(uint8_t x, uint8_t page, const char *text);
void SSD1306_WritePage(uint8_t page, uint8_t pattern);
void SSD1306_DrawBitmap(const uint8_t *data);
void SSD1306_Clear(void);
void SSD1306_DrawSignalBar(uint8_t activeSegments);
void SSD1306_DrawMainScreen(int8_t signalDb, int8_t peakDb, uint8_t activeSegments,
                            uint16_t batteryCentivolts, uint8_t beepOn);
void SSD1306_UpdateMainScreen(int8_t signalDb, int8_t peakDb, uint8_t activeSegments,
                              uint16_t batteryCentivolts);

#endif /* SSD1306_H */
