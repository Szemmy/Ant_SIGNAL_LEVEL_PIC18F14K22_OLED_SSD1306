#ifndef POWER_H
#define POWER_H

#include <stdint.h>

#define POWER_EVENT_NONE 0U
#define POWER_EVENT_WOKE 1U

void Power_Init(void);
uint8_t Power_Update(uint8_t menuButtonHeld, uint8_t menuActive);
uint8_t Power_DisplayIsOn(void);

#endif /* POWER_H */
