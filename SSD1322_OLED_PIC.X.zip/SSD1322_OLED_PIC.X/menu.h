#ifndef MENU_H
#define MENU_H

#include <stdint.h>
#include "settings.h"

void Menu_Init(void);
uint8_t Menu_Update(Settings *settings);
uint8_t Menu_IsActive(void);

#endif /* MENU_H */
